<?php include "./headerLight.php";
session_start();
?>
<body class="bg-dark">
<div class="container">
    <div class="card card-register mx-auto mt-5">
        <div class="card-header">Register an Account</div>
        <div class="card-body">
            <?php
            if (isset($_SESSION["errors"])) {
                echo "<div class='alert alert-danger'>";
                foreach ($_SESSION["errors"] as $error) {
                    echo "<li>" . $error;
                }
                echo "</div>";
            }
            ?>
            <form method="POST" action="addUser.php">
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="form-label-group">
                                <input type="text" id="firstName" name="firstName" class="form-control"
                                       placeholder="First name" required="required" autofocus="autofocus"
                                       value="<?php echo (isset($_SESSION["inputErrors"]))
                                           ? $_SESSION["inputErrors"]["firstName"]
                                           : ""; ?>">
                                <label for="firstName">First name</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-label-group">
                                <input type="text" id="lastName" name="lastName" class="form-control"
                                       placeholder="Last name" required="required"
                                       value="<?php echo (isset($_SESSION["inputErrors"]))
                                           ? $_SESSION["inputErrors"]["lastName"]
                                           : ""; ?>">
                                <label for="lastName">Last name</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-label-group">
                        <input type="email" id="inputEmail" name="inputEmail" class="form-control"
                               placeholder="Email address" required="required"
                               value="<?php echo (isset($_SESSION["inputErrors"]))
                                   ? $_SESSION["inputErrors"]["inputEmail"]
                                   : ""; ?>">
                        <label for="inputEmail">Email address</label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="form-label-group">
                                <input type="password" id="inputPassword" name="inputPassword" class="form-control"
                                       placeholder="Password" required="required">
                                <label for="inputPassword">Password</label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-label-group">
                                <input type="password" id="confirmPassword" name="confirmPassword" class="form-control"
                                       placeholder="Confirm password" required="required">
                                <label for="confirmPassword">Confirm password</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="form-label-group">
                                <img src="captcha.php">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-label-group">
                                <input type="text" id="captcha" name="captcha" class="form-control"
                                       placeholder="captcha" required="required">
                                <label for="captcha">captcha</label>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="submit" value="Register" class="btn btn-primary btn-block">
            </form>
            <?php session_destroy(); ?>
            <div class="text-center">
                <a class="d-block small mt-3" href="login.php">Login Page</a>
                <a class="d-block small" href="forgot-password.php">Forgot Password?</a>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

</body>

</html>
