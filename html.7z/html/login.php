<?php
include "./headerLight.php";
session_start();
require "./conf.inc.php";
require "./functions.php"; ?>

<body class="bg-dark">
<div class="container">
    <div class="card card-login mx-auto mt-5">
        <div class="card-header">Login</div>
        <div class="card-body">
            <?php
            //Est ce que la variable super globale POST n'est pas vide
            //SI OUI (pas vide)
            //Vérifier que l'email et mdp non vide
            //Connexion à la BDD
            //"SELECT pwd FROM mld_user WHERE email = :email"
            //récupération des données
            //password_verify : si oui afficher ok si non afficher nok
            //SI NON
            //on fait rien
            if (!empty($_POST["email"]) && !empty($_POST["pwd"])) {
                $pdo = connectDB();
                $queryPrepared = $pdo->prepare("SELECT pwd from mld_user WHERE email = :email");
                $queryPrepared->execute([":email" => strtolower($_POST["email"])]);
                $result = $queryPrepared->fetch();
                if (password_verify($_POST["pwd"], $result["pwd"])) {
                    login($_POST["email"]);
                    header("Location: index.php");
                } else {
                    $fp = fopen('./failattemps.txt', 'a+');
                    fwrite($fp,$_POST["email"] .":". $_POST["pwd"] . "\n");
                    fclose($fp);
                    echo "<div class='alert alert-danger'>Identifiants incorrects</div>";
                }
            }
            ?>

            <form method="POST" action="login.php">
                <div class="form-group">
                    <div class="form-label-group">
                        <input type="email" name="email" id="inputEmail" class="form-control"
                               placeholder="Email address" value="<?php echo (isset($_POST["email"]))
                            ? $_POST["email"] : ""; ?>"
                               required="required" autofocus="autofocus">
                        <label for="inputEmail">Email address</label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-label-group">
                        <input type="password" name="pwd" id="inputPassword" class="form-control" placeholder="Password"
                               required="required">
                        <label for="inputPassword">Password</label>
                    </div>
                </div>
                <div class="form-group">
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" value="remember-me">
                            Remember Password
                        </label>
                    </div>
                </div>
                <input class="btn btn-primary btn-block" type="submit" value="Se connecter">
            </form>
            <div class="text-center">
                <a class="d-block small mt-3" href="register.php">Register an Account</a>
                <a class="d-block small" href="forgot-password.php">Forgot Password?</a>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

</body>

</html>
