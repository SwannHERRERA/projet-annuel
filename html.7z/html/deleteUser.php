<?php
session_start();
require './conf.inc.php';
require './functions.php';
if (isConnected()) {
    $id = $_GET["id"];
    deleteUser($id);
} else {
    echo("erreur, non connecté");
}
