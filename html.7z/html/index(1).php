<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Mon super site</title>
</head>
<body>
    <h1>Accueil </h1>
    <?php
    echo "Bonjours moi, ";
    echo date("d-m-y");
    ?>
</body>
</html>