<?php
session_start();

require "./conf.inc.php";
require "./functions.php";

/* Une variable SUPER GLOBALE est une variable créée par le serveur et alimentée par le serveur. On ne peut
que la consulter. Ces variables commencent toujours par "$_" et sont en majuscules */
/*print_r($_POST);
echo $_POST['firstName'];
print_r($_SERVER);*/
/*Enoncé : ajouter une verification pour verifier que les champs ne soient pas vides*/
if (count($_POST) == 6
    && !empty($_POST['firstName'])
    && !empty($_POST['lastName'])
    && !empty($_POST['inputEmail'])
    && !empty($_POST['inputPassword'])
    && !empty($_POST['confirmPassword'])
    && !empty($_POST['captcha'])) {
    $firstName = ucwords(strtolower(trim($_POST['firstName'])));
    $lastName = strtoupper(trim($_POST['lastName']));
    $email = strtolower(trim($_POST['inputEmail']));
    $pwd = $_POST['inputPassword'];
    $pwdconfirm = $_POST['confirmPassword'];
    $captcha = strtolower($_POST['captcha']);

    /*trim() — Supprime les espaces (ou d'autres caractères) en début et fin de chaîne
    $trimmed = trim($hello, "Hdle");
    strtolower() — Renvoie une chaîne en minuscules
    strtoupper()
    ucwords() — Met en majuscule la première lettre de tous les mots
    */

    $error = false;
    $listOfErrors = [];

    //firstName : entre 2 et 50 caractères
    if (strlen($firstName) < 2 || strlen($firstName) > 50) {
        $error = true;
        $listOfErrors[] = "Le prénom doit faire entre 2 et 50 caractères";
    }
    //lastName : entre 2 et 100 caractères
    if (strlen($lastName) < 2 || strlen($lastName) > 100) {
        $error = true;
        $listOfErrors[] = "Le nom doit faire entre 2 et 100 caractères";
    }

    //captcha
    if ($captcha != $_SESSION["captcha"]) {
        $error = true;
        $listOfErrors[] = "Le captcha est incorrect";
    }

    //pwd : entre 8 et 30 caractères
    // Majuscule, minuscule, chiffres
    if (strlen($pwd) < 8 || strlen($pwd) > 30
        || !preg_match("#[a-z]#", $pwd)
        || !preg_match("#[A-Z]#", $pwd)
        || !preg_match("#\d#", $pwd)) {
        $error = true;
        $listOfErrors[] = "Le mot de passe doit faire entre 8 et 50 caractères avec des majuscules, des minuscules et des chiffres";
    }
    //pwdConfirm : correspond à pwd
    if ($pwdconfirm != $pwd) {
        $error = true;
        $listOfErrors[] = "Le mot de passe de confirmation ne correspond pas";
    }


    //email : Correspond à un format d'email
    //filter_var — Filtre une variable avec un filtre spécifique : filter_var($email_a, FILTER_VALIDATE_EMAIL
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = true;
        $listOfErrors[] = "L'email n'est pas valide";
    } elseif (!$error) {
        $pdo = connectDB();
        $queryPrepared = $pdo->prepare("SELECT id FROM mld_user WHERE email = :email");
        $queryPrepared->execute([":email" => $email]);
        /**
         * SELECT * from users
         * fetch : premier resultat, tableau 1d
         * ["firstname"=>nou,"lastname"=>"lala",...]
         * fetchAll : tout les résultats, tableau 2d
         * [0=>["firstname"=>nou,"lastname"=>"lala",...],
         * 1=>["firstname"=>nodd,"lastname"=>"laladeflhv:",...],
         * ...]
         */
        $result = $queryPrepared->fetch();
        if (!empty($result)) {
            $error = true;
            $listOfErrors[] = "L'email existe déjà";
        }
    }

    if ($error) {
        //On stock dans un coockie tous les messages d'erreurs afin de pouvoir
        //les afficher après la redirection mais on ne peut pas stocker un tableau
        //dans un coockie donc on le transforme en string avec serialise
        //setcookie("errors",serialize($listOfErrors));

        //On stock dans un coockie toutes les données provenant du formulaire afin
        //de pouvoir les remettre dans les champs en supprimant les mdp.
        unset($_POST["inputPassword"]);
        unset($_POST["confirmPassword"]);
        //setcookie("inputErrors",serialize($_POST));
        $_SESSION["errors"] = $listOfErrors;
        $_SESSION["inputErrors"] = $_POST;
        //Rediriger sur register.php
        header("Location: register.php");
        //Enoncé : rediriger vers registe.php et afficher les messages d'erreurs
    } else {
        // Ajout dans la BDD

        $query = 'INSERT INTO mld_user (firstname, lastname, email, pwd) VALUES ' .
            '(:firstname, :lastname, :email, :pwd)';


        $pwd = password_hash($pwd, PASSWORD_DEFAULT);
        $queryPrepared = $pdo->prepare($query);
        $queryPrepared->execute([
            ":firstname" => $firstName,
            ":lastname" => $lastName,
            ":email" => $email,
            ":pwd" => $pwd
        ]);
        header("Location: login.php");

    }
} else {
    die("Hack...");
}