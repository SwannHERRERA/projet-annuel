<?php include "./header.php"; ?>

    <div id="content-wrapper">

    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Cours</li>
        </ol>

        <!-- Page Content -->
        <h1>Cours</h1>
        <hr>

        <h2>Les variables</h2>

        <p>
            Définition : un élément qui contient une valeur qui peut varier.
            Attention à bien respecter le Camel Case et une variable doit toujours commencer par un "$". <br>
            Exemple : <b>$myAge</b>
        </p>
        <p>
            En PHP il n'est pas nécéssaire de déclarer et de typer les variables.
            Le type est automatique enfonction du contenu et le type est dynamique. <br>
            Je peux faire <b>$myAge = 28</b> et après je peux faire <b>$myAge = "Vingt huit"</b>
        </p>
        <p>
            En PHP7 on peut activer le strict mode qui fait que l'on doit déclarer et typer les variables.
        </p>
        <p>
            Dans le cas d'une instruction on peut avoir une erreur si la variable n'existe pas : <i>Notice: Undifined
                variable: ....</i>
            <br>
            Exemple : <b>echo $firstName;</b>
        </p>
        <ul>
            <li>String (Chaîne de caractères) <b>$firstName = "Yves"</b>
            <li>Boolean (Bool, Binary) <b>$adult = true</b>
            <li>Integer (Entier) <b>$myAge = 31</b>
            <li>Float (Virgule, decimal) <b>$average = 18.5</b>
            <li>Null <b>$correction = null</b>
        </ul>

        <h2>La concaténation</h2>
        <p>Addition de chaînes de caractères, le symbôle permettant la concaténation c'est le "."</p>
        <?php
        $firstName = "Yves";
        //Afficher bonjour Yves
        echo "Bonjour " . $firstName;
        ?>
        <br>
        <?php
        $age = 31;
        $nbYears = 2;
        //Afficher dans 2 ans vous aurez 33 ans !
        echo "Dans " . $nbYears . " ans vous aurez " . ($age + $nbYears) . " ans !";
        ?>

        <h2>Signes arithmétiques</h2>
        <ul>
            <li>Addition : +
            <li>Soustraction : -
            <li>Division : /
            <li>Multiplication : *
            <li>Modulo : %
        </ul>

        <h2>Les conditions</h2>
        <p>
            On a une variable <b>$age</b> <br>
            Si l'age est supérieur à 18 alors afficher "Majeur" <br>
            Sinon si age est égale à 18 alors afficher "Pile poil" <br>
            Sinon afficher "Mineur"
        </p>

        <?php
        $age = 12;
        if ($age > 18) {
            echo("Majeur");
        } elseif ($age == 18) {
            echo("Pile poil");
        } else {
            echo("Mineur");
        }
        ?>

        <h2>Les conditions ternaires</h2>

        <?php
        $gender = "Mr";
        if ($gender == "Mr") {
            echo "Bonjour Monsieur";
        } else {
            echo "Bonjour Madame";
        }
        ?>

        <p>Quand vous avez une condition avec un if et un else avec une seule instruction on utilise une condition
            ternaire. <br>
            syntaxe : <b>instruction(condition)?vrai:faux;</b>
        </p>

        <?php
        echo ($gender == "Mr") ? "Bonjour Monsieur" : "Bonjour Madame";
        ?>

        <h2>Les switch</h2>

        <?php
        //un note sur 5
        $mark = 5;
        switch ($mark) {
            case '0':
                echo "Nul";
                break;
            case '1':
                echo " Pas top";
                break;
            case '2':
                echo "Essaye encore";
                break;
            case '3':
                echo "Mouais";
                break;
            case '4':
                echo "Bien";
                break;
            case '5':
                echo "Peu mieux faire";
                break;
            default:
                echo "Pas possible";
        }
        ?>

        <h2>
            Les boucles
        </h2>

        <b> For (un nombre d'itération défini)</b> <br>
        <?php
        for ($ligne = 1; $ligne <= 10; $ligne++) {
            echo $ligne . " ";
        }
        ?>
        <p>
            for(déclaration et initialisation du compteur <b>;</b> le "tant que" <b>;</b> evolution du compteur){<br>
            <br>
            }
        </p>
        <p>
            Réalisez un compteur n'affichant que les nombres paire (inf 100) : <br>
            <?php
            for ($i = 0; $i <= 100; $i += 2) {
                echo $i . ", ";
            }
            ?>
        </p>
        <b>While (un nombre d'itération indéfini)</b><br>
        <?php
        $ligne = 1;
        while ($ligne <= 10) {
            echo $ligne . " ";
            $ligne++;
        }
        ?>
        <p>
            while(condition){<br>
            <br>
            }
        </p>
        <p>
            Trouve un chiffre aléatoire entre 1 et 10 et boucle tant que tu n'as pas 5<br>
            <?php
            $number = rand(1, 10);
            while ($number != 5) {
                echo $number . " ";
                $number = rand(1, 10);
            }
            ?>
        </p>
        <b>Exo marrant</b><br>
        <?php
        $n = 0;
        $n++;
        echo $n; //1
        echo $n++; //1
        echo ++$n; //3
        echo $n + 1; //4
        echo $n; //3
        echo $n = $n + 1; // 4
        echo $n;
        ?>
        <br><br>
        <b>Do While (Il doit y avoir au moins une itération)</b><br>
        <?php
        $ligne = 1;
        do {
            echo $ligne . " ";
            $ligne++;
        } while ($ligne <= 10);
        ?>
        <br><br>
        <b>Foreach (permet de parcourir un tableau PHP)</b><br>
        <?php
        $array = array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
        foreach ($array as $ligne) {
            echo $ligne . " ";
        }
        ?>
        <br><br>
        <b>Les 100 premier entre 1 et 100</b>
        <?php
        $max = 100;
        for ($current = 2; $current <= $max; $current++) {
            $isprem = true;
            for ($i = 2; $i < $current; $i++) {
                if ($current % $i == 0) {
                    $isprem = false;
                    break;
                }
            }
            if ($isprem) {
                echo $current . " ";
            }

        }
        ?>
        <br><br>
        <b>Les x premier nombres premiers</b>
        <?php
        $x = 22;
        echo "x = " . $x . "<br>";
        $start = 2;
        while ($x > 0) {
            $isPrime = true;
            for ($i = 2; $i < $start; $i++) {
                if ($start % $i == 0) {
                    $isPrime = false;
                    break;
                }
            }
            if ($isPrime) {
                echo $start . " ";
                $x--;
            }
            $start++;
        }
        ?>

        <br><br>
        <b>Les x premier nombres premiers (opti)</b>
        <?php
        $x = 22;
        echo "x = " . $x . "<br>";
        $trouve = 0;
        $current = 2;
        if ($x > 1) {
            $trouve++;
            echo "2 ";
            while ($trouve < $x) {
                $isprem = true;
                for ($i = 2; $i <= ceil(sqrt($current)); $i++) {
                    if ($current % $i == 0) {
                        $isprem = false;
                        break;
                    }
                }
                if ($isprem) {
                    echo $current . " ";
                    $trouve++;
                }
                $current++;
            }
        } elseif ($x == 1) {
            echo "2";
        }
        ?>
        <h2>Les tableaux</h2>

        <?php
        $eleve0 = array("nom", "prenom", "blabla"); // ne s'utilise plus
        $eleve = ["nom", "prenom", "blabla"];
        $eleve2 = ["prenom" => "michel", "nom" => "montigeon", "age" => "18"];
        foreach ($eleve as $tab) {
            echo $tab . " | ";
        }
        echo "<br>";
        echo $eleve[1] . "<br>";
        print_r($eleve); // utilisé pour du debug
        ?>
        <p>
            En php7 pour déclarer un tableau on utilise [] et non plus le terme array();<br>
            Exemple : <b>$student = ["pierre","marc",18];</b>
        </p>
        <?php
        $student = ["pierre", "marc", 18];
        ?>
        <p>
            Pour afficher un tableau en PHP il existe deux solutions "print_r();" ou "var_dump();"
        </p>
        <?php
        echo "print_r : ";
        print_r($eleve);
        echo "<br>var_dump : ";
        var_dump($eleve);
        ?>
        <br>
        <p>Comment faire pour afficher une seule valeur du tableau ?</p>
        <?php
        echo $student[0];
        ?>
        <br>
        <h2>Les dimensions d'un tableau</h2>
        <p>La dimension, c'est la profondeur max d'un tableau</p>
        <?php
        $listOfStudents = [
            ["firstname" => "Michel", "lastname" => "Dupont", "average" => 16],
            ["firstname" => "Claire", "lastname" => "Martin", "average" => 12],
            ["firstname" => "Laurent", "lastname" => "leclerc", "average" => 8],
            ["firstname" => "Lysiane", "lastname" => "toto", "average" => 4],
        ];
        echo $listOfStudents[1]["firstname"], " et ", ($listOfStudents[3]["firstname"] . " ont ensemble une moyenne de " . ($listOfStudents[1]["average"] + $listOfStudents[3]["average"]) / 2) . "<br>";
        echo "<ul>";
        foreach ($listOfStudents as $firstname) {
            echo "<li>", $firstname["firstname"];
        }
        echo "</ul>";
        ?>
        <?php
        echo "<table border='1'>";
        echo "<tr>";
        foreach ($listOfStudents[0] as $key => $riendutout) {
            echo "<th>" . $key . "</th>";
        }
        echo "</tr>";
        foreach ($listOfStudents as $student) {
            echo "<tr>";
            foreach ($student as $key => $info) {
                echo "<td>" . $info . "</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
        ?>
    </div>


    <!-- Sticky Footer -->
<?php include "./footer.php"; ?>