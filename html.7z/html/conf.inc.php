<?php

define("DBNAME", "devweb");
define("DBHOST", "51.75.249.213");
define("DBDRIVER", "mysql");
define("DBUSER", "root");
define("DBPWD", "fredo");