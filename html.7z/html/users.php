<?php
session_start();
require './conf.inc.php';
require './functions.php';
include './header.php';
if (!isConnected()) {
    header("Location: index.php");
} else {
$pdo = connectDB();
$results = $pdo->query("SELECT id, firstname, lastname, email, pwd FROM mld_user")->fetchAll();
?>
<div class="container-fluid">
    <table class="table">
        <thead>
        <tr>
            <th>ID</th>
            <th>Prénom</th>
            <th>Nom</th>
            <th>Email</th>
            <th>Mot de passe</th>
            <th>Supprimer</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($results as $result) {
            echo "<tr>";

            echo "<td>" . $result["id"] . "</td>";
            echo "<td>" . $result["firstname"] . "</td>";
            echo "<td>" . $result["lastname"] . "</td>";
            echo "<td>" . $result["email"] . "</td>";
            echo "<td>" . $result["pwd"] . "</td>";
            echo "<td class=\"alert-danger\"><a href='deleteUser.php?id=" . $result["id"] . "'>Supprimer</a> </td>";
            echo "</tr>";
        }
        echo "</tbody> </table> </div>";
        } ?>
