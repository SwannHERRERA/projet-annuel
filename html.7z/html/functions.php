<?php
require_once "conf.inc.php";
function connectDB()
{
    try {
        $pdo = new PDO(DBDRIVER . ":host=" . DBHOST . ";dbname=" . DBNAME, DBUSER, DBPWD);
    } catch (Exception $e) {
        die("Erreur SQL : " . $e->getMessage());
    }

    return $pdo;
}

function createToken($email)
{
    $token = md5($email . "GRAINSABLE" . time() . uniqid());
    $token = substr($token, 0, rand(15, 20));
    return $token;
}

function login($email)
{
    /**
     * creation du token
     * insertion en BDD pour l'user qui a pour email $email
     * insertion du token dans une session
     */
    $token = createToken($email);
    $pdo = connectDB();
    $pdo->query("UPDATE mld_user SET token = '" . $token . "' WHERE email = '" . $email . "'");
    $_SESSION["token"] = $token;
    $_SESSION["email"] = $email;
}

function deleteUser($id)
{
    $pdo = connectDB();
    $query = 'DELETE FROM mld_user WHERE id = :id';
    $queryPrepared = $pdo->prepare($query);
    $queryPrepared->execute([":id" => $id]);
    header("Location: users.php");
}

function isConnected()
{
    /**
     * Récupération de l'email et du token en session
     * Vérification d'une correspondance en BDD
     * Si aucune correspondance, suppression des sessions et redirection vers login.php
     * Si correspondance, nouvelle génération de token et return true
     */
    if (!empty($_SESSION["email"]) && !empty($_SESSION["token"])) {

        $email = $_SESSION["email"];
        $token = $_SESSION["token"];

        $pdo = connectDB();
        $result = $pdo->query("SELECT id FROM mld_user WHERE token = '" . $token . "' AND email = '" . $email . "'");
        if (!empty($result->fetch())) {
            login($_SESSION["email"]);
            return true;
        }
    }
    session_destroy();
    //header("Location: login.php");
    return false;
}

function logout($email)
{
    $pdo = connectDB();
    $pdo->query("UPDATE mld_user SET token= null WHERE email = '" . $email . "'");
}